package com.yudi.penjualan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PenjualanApplicationTests {

	@Test
	void contextLoads() {
	}

}
